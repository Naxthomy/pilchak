<?php
// Entrada del feed: lo ven invitados y usuarios con sesión (landing.php decide qué mostrar con is_authenticated()).
require __DIR__ . '/landing.php';
