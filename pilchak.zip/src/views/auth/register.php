<?php
include(__DIR__ . '/../_layouts/auth.layout.php');

$errors = flash_get('register_errors', []);
$old    = flash_get('register_old', []);
$next   = auth_next_from($_GET);   // 'publish' si venía del botón "+"
?>

<a class="auth-back" href="/">&larr; Volver</a>

<div class="text-center mb-4">
  <!-- ============================================================
       LOGO DE PILCHAK (REGISTRO)
       INSERTAR/REEMPLAZAR AQUÍ EL ARCHIVO DEL LOGO PERSONALMENTE.
       Es el mismo archivo que usa el login:  assets/img/logo.png
       (Si tu archivo tiene otro nombre o formato, ej. logo.svg,
        cambiá el src de la línea de abajo.)
       ============================================================ -->
  <img class="brand-logo auth-logo" src="/assets/img/logo.png" width="194" height="157" alt="Logo de Pilchak">
  <span class="brand-wordmark">PILCHAK</span>
  <p class="auth-subtitle small">Sumate a la comunidad de Pilchak</p>
</div>

<?php if (!empty($errors)): ?>
  <div class="alert alert-danger py-2 small" role="alert">
    <ul class="mb-0 ps-3">
      <?php foreach ($errors as $error): ?>
        <li><?= e($error) ?></li>
      <?php endforeach; ?>
    </ul>
  </div>
<?php endif; ?>

<form action="/src/controllers/auth/register.php" method="POST">
  <?= csrf_field() ?>
  <?php if ($next !== ''): ?><input type="hidden" name="next" value="<?= e($next) ?>"><?php endif; ?>
  <div class="mb-3">
    <label for="name" class="form-label">Usuario</label>
    <input type="text" class="form-control" id="name" name="name" placeholder="Tu usuario" maxlength="50" value="<?= e($old['name'] ?? '') ?>" required autofocus>
  </div>

  <div class="mb-3">
    <label for="email" class="form-label">E-mail</label>
    <input type="email" class="form-control" id="email" name="email" placeholder="tu@email.com" maxlength="150" value="<?= e($old['email'] ?? '') ?>" required>
  </div>

  <div class="mb-3">
    <label for="password" class="form-label">Contraseña</label>
    <input type="password" class="form-control" id="password" name="password" placeholder="Mínimo 8 caracteres" minlength="8" required>
  </div>

  <div class="mb-3">
    <label for="repeatPassword" class="form-label">Repetí tu contraseña</label>
    <input type="password" class="form-control" id="repeatPassword" name="repeatPassword" placeholder="••••••••" minlength="8" required>
  </div>

  <button type="submit" class="btn btn-primary w-100">Registrarme</button>
</form>

<div class="divider my-3">
  <span>o</span>
</div>

<button type="button" class="btn btn-google w-100 mb-3" disabled title="Próximamente">
  <svg class="google-icon" viewBox="0 0 24 24">
    <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"/>
    <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.24v3.15C3.25 21.36 7.31 24 12 24z"/>
    <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.24C.45 8.15 0 9.99 0 12s.45 3.85 1.24 5.42l4.04-3.15z"/>
    <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.25 2.64 1.24 6.58l4.04 3.15c.95-2.83 3.6-4.98 6.72-4.98z"/>
  </svg>
  Registrarse con Google (próximamente)
</button>

<div class="text-center">
  <p class="auth-footer-text small">¿Ya tenés una cuenta? <a href="<?= e(with_next('/src/views/auth/login.php', $next)) ?>">¡Inicia sesión!</a></p>
</div>
